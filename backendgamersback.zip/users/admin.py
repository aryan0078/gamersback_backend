from django.contrib import admin
from . models import Usersdata

admin.site.register(Usersdata)
# Register your models here.
